--PROJECT 2--

CREATE TABLE bankaccount (
Accountnumber NUMERIC,
Accountholdername VARCHAR(50),
Transactiondate Date,
Transactiontype VARCHAR(50),
Transactionamount NUMERIC
)
SELECT* FROM public.bankaccount

INSERT INTO public.bankaccount (accountnumber,accountholdername,transactiondate,transactiontype,transactionamount) VALUES
(1001,'RAVI_SHARMA','2023-07-01','DEPOSIT',5000.00),
(1001,'RAVI_SHARMA','2023-07-05','WITHDRAWAL',1000.00),
(1001,'RAVI_SHARMA','2023-07-10','DEPOSIT',2000.00),
(1002,'PRIYA_GUPTA','2023-07-02','DEPOSIT',3000.00),
(1002,'PRIYA_GUPTA','2023-07-08','WITHDRAWAL',500.00),
(1003,'VIKRAM_PATEL','2023-07-04','DEPOSIT',10000.00),
(1003,'VIKRAM_PATEL','2023-07-09','WITHDRAWAL',2000.00)

SELECT * FROM public.bankaccount


SELECT 
accountnumber,accountholdername,
SUM(CASE 
WHEN transactiontype ='DEPOSIT'THEN transactionamount
WHEN transactiontype ='WITHDRAWAL'THEN -transactionamount
ELSE 0
END
) AS TotalBalance
FROM public.bankaccount
GROUP BY accountnumber, accountholdername
ORDER BY accountnumber;


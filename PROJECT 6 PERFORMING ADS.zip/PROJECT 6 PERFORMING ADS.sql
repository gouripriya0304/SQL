--PROJECT 6--
CREATE TABLE performance (adid NUMERIC,
VIEWS NUMERIC,
clicks NUMERIC,
costs NUMERIC);

INSERT INTO public.performance 
VALUES(1,1000,50,20.5),
(2,800,30,15.2),
(3,1200,80,25.7),
(4,600,20,10.9),
(5,1500,120,40.3);

SELECT * FROM public.performance


SELECT adid,VIEWS,clicks,costs,concat(round((clicks/VIEWS*100),1),'%') AS CTR FROM performance 
GROUP BY adid,VIEWS,clicks,costs
ORDER BY CTR DESC;
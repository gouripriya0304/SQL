--PROJECT 3--
DROP TABLE IF EXISTS public.customer
CREATE TABLE CUSTOMER (
CUSTOMER_ID NUMERIC ,
CUSTOMER_NAME VARCHAR(50)
)
INSERT INTO public.customer (CUSTOMER_ID,CUSTOMER_NAME) VALUES (1,'JOE'),(2,'HENRY'),(3,'SAM'),(4,'MAX')

SELECT * FROM public.customer

CREATE TABLE ORDERS (
ORDER_ID NUMERIC,
CUSTOMER_ID NUMERIC
)

INSERT INTO public.orders (ORDER_ID,CUSTOMER_ID) VALUES (2,1),(1,3)

SELECT * FROM public.orders 

SELECT customer_name FROM public.customer AS c
LEFT JOIN public.orders o ON c.customer_id=o.customer_id
WHERE o.customer_id IS NULL


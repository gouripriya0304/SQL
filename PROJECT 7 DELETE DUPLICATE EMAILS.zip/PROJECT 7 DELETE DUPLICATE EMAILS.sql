--PROJECT 7--
CREATE TABLE EMAILS (
ID NUMERIC,
NAME VARCHAR(50),
EMAIL VARCHAR(50),
PHONE NUMERIC
)
INSERT INTO public.emails (ID,NAME,EMAIL,PHONE)VALUES
(1,'Rahul','rahul@exmple.com',9839473902),
(2,'Rohit','rohit@example.com',9883782971),
(3,'Suresh','rahul@exmple.com',7654321098),
(4,'Manish','manish@example.com',8927394619),
(5,'Amit','amit@example.com',9399303840),
(6,'Rahul','rahul@exmple.com',9737466147)

SELECT * FROM public.emails

DELETE FROM Emails
WHERE id NOT IN (
    SELECT MIN(id)
    FROM Emails
    GROUP BY email
);





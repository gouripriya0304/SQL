--PROJECT 1--
DROP TABLE IF EXISTS public.product
CREATE TABLE product (
product_id NUMERIC,
product_name VARCHAR(50),
selling_price NUMERIC
)
 SELECT * FROM public.product
 
INSERT INTO public.product (product_id,product_name,selling_price) VALUES(1,'product A',100.00),(2,'product B',150.00),(1,'product A',120.00),(3,'product C',200.00),(2,'product B',180.00),(1,'product A',90.00),(3,'product C',210.00)

 SELECT * FROM public.product
 
 SELECT product_name,round( avg(selling_price),6)
 AS avg_selling_price FROM public.product
 GROUP BY product_name
 ORDER BY avg_selling_price ASC
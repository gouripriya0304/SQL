--PROJECT 8--

CREATE TABLE NAMES(
NAME VARCHAR(50)
)

INSERT INTO public."names"(NAME) VALUES('rAVI kUMAR'),('priya sharma'),('amit PATEL'),('NEHA gupta')
SELECT * FROM public."names


UPDATE Names
SET Name = INITCAP(TRIM(Name));

select * from public."NAMES"
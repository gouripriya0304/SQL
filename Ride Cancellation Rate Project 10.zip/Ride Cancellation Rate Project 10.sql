DROP TABLE IF EXISTS public.product
CREATE TABLE product(
id NUMERIC,
Cilentid NUMERIC,
Driverid NUMERIC,
Cityid NUMERIC,
Status VARCHAR,
Request_at Date
)

    INSERT INTO public.product 
    (id,Cilentid,Driverid,Cityid,Status,Request_at ) 
    VALUES
    (1,1,10,1,'completed','2023-07-12'),(2,2,11,1,'Cancelled by driver','2023-07-12'),(3,3,12,6,'completed','2023-07-12'),(4,4,13,6,
    'Cancelled by clinet','2023-07-12'),(5,1,10,1,'completed','2023-07-13'),(6,2,11,6,'completed','2023-07-13'),(7,3,12,6,'completed','2023-07-13'),(8,2,12,12,'completed','2023-07-14'),(9,03,10,12,'completed','2023-07-14'),(10,04,13,12,'Cancelled by driver','2023-07-14')
    
    SELECT * FROM public.product
 
 
 DROP TABLE IF EXISTS public.users   
CREATE TABLE users(
user_id NUMERIC,
banned VARCHAR,
Roles VARCHAR
)

INSERT INTO public.users(user_id,banned,roles)
VALUES
(1,'NO','client'),
(2,'YES','client'),
(3,'NO','client'),
(4,'NO','client'),
(10,'NO','Driver'),
(11,'NO','Driver'),
(12,'NO','Driver'),
(13,'NO','Driver');

SELECT * FROM public.users

SELECT Request_at,ROUND(SUM
(CASE 
WHEN LOWER(p.Status) IN ('cancelled by driver', 'cancelled by clinet') THEN 1 ELSE 0 
END
  )* 1.0 / COUNT(*),
        4
    ) AS cancellation_rate
FROM product p
JOIN users u ON p.Cilentid = u.user_id
WHERE LOWER(u.banned) = 'no'AND LOWER(u.roles) = 'client'
GROUP BY p.Request_at
ORDER BY p.Request_at;





    
    
    
    
    
    
    
    




